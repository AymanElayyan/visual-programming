﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sale_Price_Calculator
{
    public partial class Basic_Arithmetic_Operations : Form
    {
        float firstNum, secNum;

        public Basic_Arithmetic_Operations()
        {
            InitializeComponent();
        }

        private void firstNumber_TextChanged(object sender, EventArgs e)
        {

            
        }

        private void resulte_TextChanged(object sender, EventArgs e)
        {

        }

        private void Subtract_Click(object sender, EventArgs e)
        {
            firstNum = float.Parse(firstNumber.Text);
            secNum = float.Parse(secondNumber.Text);
            float res = firstNum - secNum;
            resulte.Text = res.ToString();
        }

        private void multiplication_Click(object sender, EventArgs e)
        {
            firstNum = float.Parse(firstNumber.Text);
            secNum = float.Parse(secondNumber.Text);
            float res = firstNum * secNum;
            resulte.Text = res.ToString();
        }

        private void Division_Click(object sender, EventArgs e)
        {
            firstNum = float.Parse(firstNumber.Text);
            secNum = float.Parse(secondNumber.Text);
            float res = firstNum / secNum;
            resulte.Text = res.ToString();
        }

        private void clear_Click(object sender, EventArgs e)
        {
            firstNumber.Text = "";
            secondNumber.Text = "";
            resulte.Text = "";
        }

        private void sum_Click(object sender, EventArgs e)
        {
            firstNum = float.Parse(firstNumber.Text);
            secNum = float.Parse(secondNumber.Text);
            float res = firstNum + secNum;
            resulte.Text = res.ToString();
            
        }
    }
}
